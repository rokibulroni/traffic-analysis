./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_1/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_1/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_2/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_2/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_3/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_3/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_4/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc1_4/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_1/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_1/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_2/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_2/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_3/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_3/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_4/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_4/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_5/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_5/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_6/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc2_6/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc3_1/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc3_1/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc3_2/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc3_2/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc4_1/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc4_1/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc4_2/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc4_2/img1/
./bin /home/ipl_gpu/Thomas/aicity18/Track3/Loc4_3/vdo.mp4 /home/ipl_gpu/Thomas/aicity18/Track3/Loc4_3/img1/


